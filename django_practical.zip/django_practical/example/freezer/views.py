from django.http import HttpResponse


# Create your views here.

def contents(request):
	return HttpResponse('Here are the contents of the freezer...')

def species(request):
	return HttpResponse("Retrieve species")

def person(request):
	return HttpResponse("Retrieve person")

def strain(request):
	return HttpResponse("Retrieve strain")

def sample(request):
	return HttpResponse("Retrieve sample")
