from django.shortcuts import render,render_to_response
from django.http import HttpResponse

from freezer.models import *

# Create your views here.

def contents(request):
	sample_list = Sample.objects.all().order_by('-date')
	return render(request,'contents2.html',{'sample_list': sample_list})
#	output = ', '.join(s.label for s in sample_list)
#	return HttpResponse(output)


def species(request):
	return HttpResponse("Retrieve species")

def person(request):
    if request.method  == 'POST':
        data = request.POST
        p = Person(
            firstname = data['firstname'], 
            lastname = data['lastname'], 
            email = data['email']
            )
        p.save()
    person_list = Person.objects.all().order_by('lastname')
    return render(request,'person.html', {'person_list': person_list})

def strain(request):
    if request.method  == 'POST':
        data = request.POST
        s = Strain(
            name = data['name'], 
            mutation = data['mutation'], 
            species = Species.objects.get(id=data['species_id'])
            )
        s.save()
    strain_list = Strain.objects.all().order_by('name')
    species_list = Species.objects.all().order_by('name')
    return render(request,'strain.html', {'strain_list': strain_list, 'species_list': species_list})

def sample(request):
    if request.method  == 'POST':
        data = request.POST
        s = Sample(
            label = data['label'], 
            date = data['date'], 
            strain = Strain.objects.get(id=data['strain_id']), 
            person = Person.objects.get(id=data['person_id']),
            notes = data['notes']
            )
        s.save()
    sample_list = Sample.objects.all().order_by('label')
    strain_list = Strain.objects.all().order_by('name')
    person_list = Person.objects.all().order_by('lastname')
    return render(request,'sample.html', {'sample_list': sample_list, 'strain_list': strain_list, 'person_list': person_list})
