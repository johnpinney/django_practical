from django.conf.urls import url
from freezer import views

urlpatterns = [
    url(r'^contents', views.contents),
    url(r'^person', views.person),
    url(r'^species', views.species),
    url(r'^strain', views.strain),
    url(r'^sample', views.sample),
]

