

from django.db import models

# Create your models here.
class Person(models.Model):
	firstname = models.CharField(max_length=100)

class Species(models.Model):
	PHYLA = (
		('AD', 'Acidobacteria'),
		('AT', 'Actinobacteria'),
	   	('AQ', 'Aquificae'),
	    	('BA', 'Bacteroidetes'),
	    	('CA', 'Caldiserica'),
	    	('CM', 'Chlamydiae'),
	    	('CB', 'Chlorobi'),
	    	('CF', 'Chloroflexi'),
	    	('CG', 'Chrysiogenetes'),
	    	('CY', 'Cyanobacteria'),
	    	('DF', 'Deferribacteres'),
	    	('DT', 'Deinococcus-Thermus'),
	    	('DI', 'Dictyoglomi'),
	    	('EL', 'Elusimicrobia'),
	    	('FB', 'Fibrobacteres'),
	    	('FM', 'Firmicutes'),
	    	('FU', 'Fusobacteria'),
	    	('GE', 'Gemmatimonadetes'),
	    	('LE', 'Lentisphaerae'),
	    	('NI', 'Nitrospira'),
	    	('PL', 'Planctomycetes'),
	    	('PR', 'Proteobacteria'),
	    	('SP', 'Spirochaetes'),
	    	('SY', 'Synergistetes'),
	    	('TE', 'Tenericutes'),
	    	('TD', 'Thermodesulfobacteria'),
	    	('TT', 'Thermotogae'),
	    	('VE', 'Verrucomicrobia'),
		)
	name = models.CharField(max_length=100)
	phylum = models.CharField(max_length=2, choices=PHYLA)

class Strain(models.Model):
	name = models.CharField(max_length=100)

class Sample(models.Model):
	label = models.CharField(max_length=100)
	date = models.DateField('date frozen')
	notes = models.CharField(max_length=1000)
	person = models.ForeignKey(Person,models.CASCADE)
	strain = models.ForeignKey(Strain,models.CASCADE)
